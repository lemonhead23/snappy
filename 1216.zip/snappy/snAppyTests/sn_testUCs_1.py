#!/usr/bin/python3
# -*- coding: utf-8 -*-

pass

testCalls = """

standard manual functionality tests:

standalone wrapper that sends a predefined list of curl calls to snApi at 7800



"""
